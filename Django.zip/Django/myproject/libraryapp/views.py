# library/views.py
from django.shortcuts import render, redirect
from .models import Book, Author
from .forms import BookForm, AuthorForm

def library_view(request):
    if request.method == 'POST':
        book_form = BookForm(request.POST, prefix='book')
        author_form = AuthorForm(request.POST, prefix='author')
        if book_form.is_valid():
            book_form.save()
            return redirect('library_view')
        if author_form.is_valid():
            author_form.save()
            return redirect('library_view')
    else:
        book_form = BookForm(prefix='book')
        author_form = AuthorForm(prefix='author')

    books = Book.objects.all()
    authors = Author.objects.all()
    return render(request, 'library/library_view.html', {
        'books': books,
        'authors': authors,
        'book_form': book_form,
        'author_form': author_form
    })
