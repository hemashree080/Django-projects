from django.contrib import admin
from django.contrib import admin
from .models import Author, Book

@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ('name', 'birthdate')
    list_filter = ('birthdate',)
    search_fields = ('name',)
    date_hierarchy = 'birthdate'

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'published_date', 'genre')
    list_filter = ('author', 'published_date', 'genre')
    search_fields = ('title', 'author__name')
    date_hierarchy = 'published_date'

# Register your models here.
