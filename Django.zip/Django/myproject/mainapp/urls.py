from django.contrib import admin
from django.urls import path
from mainapp.views import StudentListView, StudentDetailView, home, register_project, register_student

urlpatterns = [
    path('admin/', admin.site.urls),  # Ensure this is only defined once
    path('', home, name='home'),
    path('students/', StudentListView.as_view(), name='student_list'),
    path('students/<int:pk>/', StudentDetailView.as_view(), name='student_detail'),
    path('register_project/', register_project, name='register_project'),
    path('register_student/', register_student, name='register_student'),
]