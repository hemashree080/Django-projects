from django.contrib import admin
from .models import Project, Student, Course

admin.site.register(Project)
admin.site.register(Student)
admin.site.register(Course)