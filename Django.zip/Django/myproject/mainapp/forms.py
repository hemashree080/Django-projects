from django import forms
from .models import Project, Student, Course

class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['title', 'description']

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['first_name', 'last_name', 'email', 'course', 'project']

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['title', 'description']