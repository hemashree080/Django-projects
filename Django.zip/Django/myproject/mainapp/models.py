from django.db import models

class Project(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField(default="")  # Default value added here

    def _str_(self):
        return self.title

class Student(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField()
    course = models.ForeignKey('Course', on_delete=models.SET_NULL, null=True)
    project = models.ForeignKey(Project, on_delete=models.SET_NULL, null=True)

    def _str_(self):
        return f'{self.first_name} {self.last_name}'

class Course(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()

    def _str_(self):
        return self.title