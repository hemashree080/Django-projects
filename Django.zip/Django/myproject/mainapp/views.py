from django.shortcuts import render, redirect
from .models import Project, Student, Course
from .forms import ProjectForm, StudentForm, CourseForm
from django.views.generic import ListView, DetailView

def home(request):
    projects = Project.objects.all()
    students = Student.objects.all()
    return render(request, 'main/home.html', {'projects': projects, 'students': students})

def register_project(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = ProjectForm()
    return render(request, 'main/register_project.html', {'form': form})

def register_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = StudentForm()
    return render(request, 'main/register_student.html', {'form': form})

def register_course(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = CourseForm()
    return render(request, 'main/register_course.html', {'form': form})

class StudentListView(ListView):
    model = Student
    template_name = 'main/student_list.html'

class StudentDetailView(DetailView):
    model = Student
    template_name = 'main/student_detail.html'

//from django.contrib import admin
from django.urls import include, path
from mainapp.views import StudentListView, StudentDetailView, home, register_project, register_student, register_course

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('students/', StudentListView.as_view(), name='student_list'),
    path('students/<int:pk>/', StudentDetailView.as_view(), name='student_detail'),
    path('register_project/', register_project, name='register_project'),
    path('register_student/', register_student, name='register_student'),
    path('register_course/', register_course, name='register_course'),
    path('', include('mainapp.urls')),
]