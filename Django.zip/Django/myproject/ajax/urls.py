from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('search/', views.search, name='search'),
    path('ajax_search/', views.ajax_search, name='ajax_search'),
]


