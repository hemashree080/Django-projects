from django.db import models

class Student(models.Model):
    fullname = models.CharField(max_length=60)
    email = models.EmailField(unique=True)
    course = models.CharField(max_length=255)

    def __str__(self):
        return self.fullname
