from django.shortcuts import render, redirect
from django.http import JsonResponse
from .forms import StudentForm
from .models import Student

def register(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('register')
    else:
        form = StudentForm()
    return render(request, 'register.html', {'form': form})

def search(request):
    return render(request, 'search.html')

def ajax_search(request):
    query = request.GET.get('query', '')
    if query:
        results = Student.objects.filter(fullname__icontains=query)
        results_list = list(results.values('fullname', 'email', 'course'))
    else:
        results_list = []
    return JsonResponse({'results': results_list})

