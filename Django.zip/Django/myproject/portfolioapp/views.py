from django.shortcuts import render
from django.shortcuts import render
def main(request):
 return render(request, 'portfolio/home.html')
def about(request):
 return render(request, 'portfolio/about.html')
def contact(request):
 return render(request, 'portfolio/contact.html')

# Create your views here.
