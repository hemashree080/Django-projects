# book/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('books/export/csv/', views.export_books_csv, name='export_books_csv'),
    path('books/export/pdf/', views.export_books_pdf, name='export_books_pdf'),
]