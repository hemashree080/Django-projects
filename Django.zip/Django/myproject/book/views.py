# book/views.py
import csv
from django.http import HttpResponse
from .models import Book
from django.http import FileResponse 
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

def export_books_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="books.csv"'

    writer = csv.writer(response)
    writer.writerow(['Title', 'Author', 'Publication Date'])

    books = Book.objects.all().values_list('title', 'author', 'publication_date')
    for book in books:
        writer.writerow(book)

    return response

def export_books_pdf(request):
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    p.setFont("Helvetica", 12)

    books = Book.objects.all()
    y = 750

    p.drawString(100, 800, "Book List")
    p.drawString(100, y, "Title")
    p.drawString(250, y, "Author")
    p.drawString(400, y, "Publication Date")
    y -= 25

    for book in books:
        p.drawString(100, y, book.title)
        p.drawString(250, y, book.author)
        p.drawString(400, y, book.publication_date.strftime('%Y-%m-%d'))
        y -= 25

    p.showPage()
    p.save()
    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename='books.pdf')