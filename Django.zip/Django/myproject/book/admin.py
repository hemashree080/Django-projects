# book/admin.py
from django.contrib import admin
from .models import Book, Project

admin.site.register(Book)
admin.site.register(Project)